CREATE DATABASE IF NOT EXISTS `taller_software`;

USE `taller_software`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `cliente`;

CREATE TABLE `cliente` (
  `Rut` varchar(10) NOT NULL,
  `Nombre` varchar(30) DEFAULT NULL,
  `Apellido` varchar(30) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Direccion` varchar(30) DEFAULT NULL,
  `Telefono` varchar(30) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_up` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `ultima_visita` varchar(30) DEFAULT NULL,
  `tiempo_visita` time DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `ip_cliente` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Rut`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `cliente` VALUES ("18339188-7","Victor","Castillo","carlos@castillo.cl","las flores 2020",654123655,"$2y$10$dZ/wN4XUCmintYEwLzo0pOUoWjJxHsGrJoJ2XYkV99IqPAaH7wc26","2020-09-07 16:38:38","2020-09-07 12:51:53","2020-09-07 16:38:38","2020 07 09  19:31:08","19:33:24",NULL,NULL),
("24935605-0","Javiera","Miranda","javi@javi.com","los alamos 254",987456325,"$2y$10$FKl/XK17JUTAVII54zwSvuT7iKx643KCqztRS4zErUKIA6wnkU9p.","2020-09-07 13:58:53","2020-09-07 12:51:53","2020-09-07 13:58:53","2020 07 09  15:01:28","16:58:53",NULL,NULL),
("8448232-3","Manuel","Lopez","manuel@manuel.cl","las golondrinas 555",874565777,"$2y$10$a.l6.rMN6FOF7k8BNCul1uaxKlzB5AstLeB4bQ3p1r30M2WCPhQyG","2020-09-07 16:38:42","2020-09-07 16:36:33","2020-09-07 16:38:42","2020 07 09  19:37:58","19:38:42",NULL,NULL),
("15018662-5","Estevan","Rozas","estevan@gmail.com","las amapolas 145",321564852,"$2y$10$lVkSf4lBX7tbLmu8pSTG..IWUTtpl3gsY/YwHzBYvJ9NW2vfbk.KK","2020-09-07 17:18:36","2020-09-07 17:14:40","2020-09-07 17:18:36","2020 07 09  20:18:34","20:18:36","Windows NT LAPTOP-A7TMQ9HO 10.0 build 19041 (Windows 10) AMD64","::1");


DROP TABLE IF EXISTS `probando`;

CREATE TABLE `probando` (
  `rut` varchar(10) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_up` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `ultima_visita` datetime DEFAULT NULL,
  `tiempo_visita` time DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`rut`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `probando` VALUES ("17860433-3","Fanny",NULL,"2020-09-07 02:08:08","2020-09-07 12:49:45","0000-00-00 00:00:00",NULL,NULL,NULL),
("17860433-8","cory",NULL,"2020-09-07 02:08:08","2020-09-07 12:49:45","0000-00-00 00:00:00",NULL,NULL,NULL),
("13445849-9","papapa",NULL,"2020-09-07 02:08:08","2020-09-07 12:49:45","0000-00-00 00:00:00",NULL,NULL,NULL),
(234546788,"dsaasdasdasd",NULL,"2020-09-07 02:08:08","2020-09-07 12:49:45","0000-00-00 00:00:00",NULL,NULL,NULL),
("13448949-9","dsaasdasdasd",NULL,"2020-09-07 02:08:08","2020-09-07 12:49:45","0000-00-00 00:00:00",NULL,NULL,NULL),
("6233355-3","Carolina",123456,"2020-09-07 02:08:08","2020-09-07 12:49:45","0000-00-00 00:00:00",NULL,NULL,NULL),
("13444888-1","Fanny","$2y$10$jBDljzbBJ25KP4UbJu1mluO/E8aULJHVhSyu1TOGIUcTsQaLo4gIS","2020-09-07 02:08:08","2020-09-07 12:49:45","0000-00-00 00:00:00",NULL,NULL,NULL),
("13444888-2","Fanny","","2020-09-07 02:08:08","2020-09-07 12:49:45","0000-00-00 00:00:00",NULL,NULL,NULL),
("13444888-3","fanny","$2y$10$yuzVyogEi2IEGrQ4fc9OietjwlLRRzG/kYPQTvzD88Emn/39c2VLm","2020-09-07 02:08:08","2020-09-07 12:49:45","0000-00-00 00:00:00",NULL,NULL,NULL),
("21986393-1","Conan","$2y$10$LM5YKhXfoQ77uEr.Ig/enOXLMVz/Kd6YFkBqLAOb1TUcb19PF0lxi","2020-09-07 02:08:08","2020-09-07 12:49:45","0000-00-00 00:00:00",NULL,NULL,NULL),
("15448884-5","hugo","$2y$10$x2Q3IQVcxtZYi/ihqD33Iu0Lib6ll1b93sx0h1RfM4UNTqxtrWVMu","2020-09-07 02:08:56","2020-09-07 12:49:45","0000-00-00 00:00:00",NULL,NULL,NULL);


SET foreign_key_checks = 1;
